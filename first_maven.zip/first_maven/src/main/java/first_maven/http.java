package first_maven;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class http {
	public static void main(String args[]) throws Exception{
		int choose=menu();
		while(choose<=6&&choose>0) {
			switch(choose) {
			case 1:getinformationpost();break;
			case 2:gettianqi();break;
			case 3:getipplace();break;
			case 4:getword();break;
			case 5:getchange();break;
			case 6:getstar();break;
			default:System.out.println("������������������0-6");
			}
			Scanner sc=new Scanner(System.in);
			choose=menu();
		}
	}
	
	
	//�������Ʋ�ѯ
    private static String getstar() throws Exception{
    	Scanner scan=new Scanner(System.in);
    	String  star="";
    	String AppKey="da8298f87a85f8ddcb1b4b1724af84d5";
		CloseableHttpClient httpclient=HttpClients.createDefault();
		HttpPost httpPost=new HttpPost("http://web.juhe.cn:8080/constellation/getAll");
		
		System.out.println("���������ѯ������");
		String stars=scan.next();
		
		System.out.println("���������ѯ���Ƶ�����  ���磨today��tomorrow...��");
		String data=scan.next();
		
	
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("consName",stars));
		parameters.add(new BasicNameValuePair("type",data));
		parameters.add(new BasicNameValuePair("key",AppKey));
		//����ʵ��
				UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
				httpPost.setEntity(formEntity);
				CloseableHttpResponse response=null;
				//
				try {
					response=httpclient.execute(httpPost);
					if(response.getStatusLine().getStatusCode()==200) {
						star=EntityUtils.toString(response.getEntity(), "utf-8");
						System.out.println(star);
					}
				}catch(Exception e) {
					e.printStackTrace();
				}finally {
					if(response!=null) {
						response.close();
					}
					httpclient.close();
				}
				return star;	
	}
	//��/��ת��
	private static String getchange() throws Exception{
		Scanner scan=new Scanner(System.in);
		String text="";
	
		System.out.println("��������ת��������");
		String words=scan.next();
		System.out.println("��������ת�������ֵ�����");
		
		System.out.println("0.����  1.���� ");
		String type1=scan.next();
		
		String AppKey="f4e0567bb5da7139b0ce3e28b27dec99";
		CloseableHttpClient httpclient=HttpClients.createDefault();
		HttpPost httpPost=new HttpPost("http://japi.juhe.cn/charconvert/change.from");
		
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("text",words));
		parameters.add(new BasicNameValuePair("type",type1));
		parameters.add(new BasicNameValuePair("key",AppKey));
				
		//����ʵ��
		UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
		httpPost.setEntity(formEntity);
		CloseableHttpResponse response=null;
		//
		try {
			response=httpclient.execute(httpPost);
			if(response.getStatusLine().getStatusCode()==200) {
				text=EntityUtils.toString(response.getEntity(), "utf-8");
				System.out.println(text);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(response!=null) {
				response.close();
			}
			httpclient.close();
		}
		return text;
		//		
	}

	////�����/����ʲ�ѯ
	private static String getword() throws Exception {
		Scanner scan=new Scanner(System.in);
		String word="";
		String AppKey="1815290955af971c36952be54e957972";
		CloseableHttpClient httpclient=HttpClients.createDefault();
		HttpPost httpPost=new HttpPost("http://apis.juhe.cn/tyfy/query");
		System.out.println("������������ľ���");
		String words=scan.next();
		
		
		System.out.println("��������ת������:1.ͬ��� 2.�����");
		String types=scan.next();
		
		
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("word",words));
		parameters.add(new BasicNameValuePair("type",types));
		parameters.add(new BasicNameValuePair("key",AppKey));
		
		//����ʵ��
		UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
		httpPost.setEntity(formEntity);
		CloseableHttpResponse response=null;
		//
		try {
			response=httpclient.execute(httpPost);
			if(response.getStatusLine().getStatusCode()==200) {
				word=EntityUtils.toString(response.getEntity(), "utf-8");
				System.out.println(word);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(response!=null) {
				response.close();
			}
			httpclient.close();
		}
		return word;
}
		

	//�ֻ��Ų�ѯ
	public static String getinformationpost() throws Exception{
		Scanner scan=new Scanner(System.in);
		CloseableHttpClient httpclient=HttpClients.createDefault();
		String content="";
		HttpPost httpPost=new HttpPost("https://tcc.taobao.com/cc/json/mobile_tel_segment.htm");
		String phones;
		System.out.println("���������ѯ���ֻ�����");
		phones=scan.next();
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("tel", phones));
		//����ʵ��
		UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
		httpPost.setEntity(formEntity);
		
		CloseableHttpResponse response=null;
		try {
			response=httpclient.execute(httpPost);
			if(response.getStatusLine().getStatusCode()==200) {
				content=EntityUtils.toString(response.getEntity(), "utf-8");
				System.out.println(content);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(response!=null) {
				response.close();
			}
			httpclient.close();
		}
		return content;
	}
	
	//����Ԥ��
	public static String gettianqi() throws Exception{
		Scanner scan=new Scanner(System.in);
		String tianqi="";
		String citys;
		System.out.println("���������ѯ�����ĳ���");
		citys=scan.next();
		String AppKey="49bbcf8433bbf4c8b06a83ccd1e098ae";
		CloseableHttpClient httpclient=HttpClients.createDefault();
		HttpPost httpPost=new HttpPost("http://apis.juhe.cn/simpleWeather/query");
		
		
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("city", citys));
		parameters.add(new BasicNameValuePair("key", AppKey));
		
		//����ʵ��
		UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
		httpPost.setEntity(formEntity);
		CloseableHttpResponse response=null;
		try {
			response=httpclient.execute(httpPost);
			System.out.println(response.getStatusLine().getStatusCode());
			if(response.getStatusLine().getStatusCode()==200) {
				tianqi=EntityUtils.toString(response.getEntity(), "utf-8");
				System.out.println(tianqi);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(response!=null) {
				response.close();
			}
			httpclient.close();
		}
		return tianqi;
	}
	
	//ip��ַ��ѯ
	public static void getipplace() throws Exception{
		Scanner scan=new Scanner(System.in);
		CloseableHttpClient httpclient=HttpClients.createDefault();
		String AppKey="538e1722e77a2f6e8bea4ec73465ba3d";
		String content="";
		HttpPost httpPost=new HttpPost("http://apis.juhe.cn/ip/ipNew");
		String ips;
		System.out.println("���������ѯ��ip");
		ips=scan.next();
		
		//���ò���
		List<BasicNameValuePair> parameters=new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("ip", ips));
		parameters.add(new BasicNameValuePair("key",AppKey));
		//����ʵ��
		UrlEncodedFormEntity formEntity=new UrlEncodedFormEntity(parameters,"utf-8");
		httpPost.setEntity(formEntity);
				
		CloseableHttpResponse response=null;
		try {
			response=httpclient.execute(httpPost);
			if(response.getStatusLine().getStatusCode()==200) {
				content=EntityUtils.toString(response.getEntity(), "utf-8");
				System.out.println(content);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(response!=null) {
				response.close();
			}
			httpclient.close();
		}
		
	}
	
	public static int menu() {
		int choose;
		System.out.println("**********����ٱ���**********");
		System.out.println("*****1.�ֻ��Ų�ѯ�����ز�ѯ****");
		System.out.println("********2.����Ԥ����ѯ*********");
		System.out.println("********3.ip��ַ��ѯ***********");
		System.out.println("*******4.ͬ���/����ʲ�ѯ*****");
		System.out.println("*********5.��/��ת��***********");
		System.out.println("********6.�������Ʋ�ѯ**********");
		System.out.println("************0.�˳�*************");
		Scanner scan=new Scanner(System.in);
		System.out.println("����������ѡ��");
		choose=scan.nextInt();
		return choose;
	}

}
